package Com.nt.Employee;
/**
 * Interface in java to implement methods in classes*/
public interface IEmployee {
    Employee addEmployee(Employee employee);
    void deleteEmployee(Employee employee);
    int calculateSalary();
}
